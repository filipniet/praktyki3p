package zadanie2;

public class Person {
    int id;
    String name;
    String date;
    Person(int id, String name, String date){

    }

    void copy(int a){
        int b = a;
    }
}
