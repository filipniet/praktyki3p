package zadanie13;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner skaner = new Scanner(System.in);
        System.out.print("Podaj liczbę : ");
        String input = skaner.nextLine();
        float liczba = Float.parseFloat(input);
        System.out.println("Podana liczba: " + liczba);
    }
}
