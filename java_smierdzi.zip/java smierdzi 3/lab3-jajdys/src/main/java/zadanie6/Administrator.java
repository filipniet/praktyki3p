package zadanie6;

public class Administrator extends Employee{
    String certificates;

    public Administrator(String name, String surename, String certificates) {
        super(name, surename);
        this.certificates = certificates;
    }
    public void printInfo()
    {
        System.out.println();
        System.out.println("Administrator:");
        System.out.println(name);
        System.out.println(surename);
        System.out.println(certificates);
    }
}
