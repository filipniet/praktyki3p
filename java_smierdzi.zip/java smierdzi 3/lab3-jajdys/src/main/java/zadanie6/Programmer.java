package zadanie6;

public class Programmer extends Employee{
    String languages;
    public Programmer(String name, String surename, String languages) {
        super(name, surename);
        this.languages = languages;
    }
    public void printInfo(){
        System.out.println();
        System.out.println("Programista:");
        System.out.println(name);
        System.out.println(surename);
        System.out.println(languages);
    }
}
