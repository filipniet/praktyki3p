package zadanie6;

public class Main {
    public static void main(String[] args) {
        Employee Prac = new Employee("Bartek", "Złotopolski");
        Administrator Admin = new Administrator("Michał", "Kurpiowski", "C#");
        Programmer programista = new Programmer("Artur", "Brzozowski", "Python, C++");

        Prac.printInfo();
        Admin.printInfo();
        programista.printInfo();
    }
}
