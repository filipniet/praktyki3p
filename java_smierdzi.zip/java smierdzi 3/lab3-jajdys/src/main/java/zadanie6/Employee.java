package zadanie6;

public class Employee {
    String name;
    String surename;
    public Employee()
    {

    }
    public Employee(String name, String surename)
    {
        this.name = name;
        this.surename = surename;
    }
    public void printInfo()
    {
        System.out.println();
        System.out.println("Pracownik:");
        System.out.println(name);
        System.out.println(surename);
    }
}
