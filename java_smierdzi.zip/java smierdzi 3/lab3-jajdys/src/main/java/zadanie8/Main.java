package zadanie8;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Flat[] homes = new Flat[10];
        Random random = new Random();

        int losowanie;
        for(int i=0; i<homes.length; i++){
            losowanie = random.nextInt(3);
            if(losowanie==0){
                homes[i] = new Flat("Gdańsk", "Mickiewicza");
            }
            else if (losowanie==1) {
                homes[i] = new House("Sopot", "Sienkiewicza", 65.3f);
            }
            else if (losowanie ==2){
                homes[i] = new Residence("Ujazdowo", "Fredry", 23.7f, 12.5f);
            }
        }
        for(int i=0; i< homes.length; i++)
        {
            if(homes[i] instanceof Residence)
            {
                Residence domostwo = (Residence) homes[i];
                System.out.println(domostwo.getGarageSize());
                System.out.println(domostwo.toString());
            } else if (homes[i] instanceof House)
            {
                House mieszkanie = (House) homes[i];
                System.out.println(mieszkanie.getParcelSize());
                System.out.println(mieszkanie.toString());
            } else{
                Flat pietro = (Flat) homes[i];
                System.out.println(pietro.toString());
            }
        }
    }
}
