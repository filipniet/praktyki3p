package zadanie11;

public class Angle {
    private double x;
    public Angle(double x) {
        this.x = Math.toRadians(x);
    }
    public double Sinus(double x)
    {
        return Math.sin(x);
    }
    public double Cosinus(double x)
    {
        return Math.cos(x);
    }
    public double Tanges(double x)
    {
        return Math.tan(x);
    }
    public double Cotanges(double x)
    {
        return 1.0/Math.tan(x);
    }
    public double Secans(double x)
    {
        return 1.0/Math.cos(x);
    }
    public double Cosecans(double x)
    {
        return 1.0/Math.sin(x);
    }
}