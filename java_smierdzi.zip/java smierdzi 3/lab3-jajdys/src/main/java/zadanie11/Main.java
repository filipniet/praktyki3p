package zadanie11;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner skaner = new Scanner(System.in);

        System.out.print("Podaj miarę kąta w radianach: ");
        double radian = skaner.nextDouble();

        Angle radiany = new Angle(radian);
        System.out.println("");
        System.out.println("Sinus wynosi: " + radiany.Sinus(radian));
        System.out.println("Cosinus wynosi: " + radiany.Cosinus(radian));
        System.out.println("Tanges wynosi: " + radiany.Tanges(radian));
        System.out.println("Cotanges  wynosi: " + radiany.Cotanges(radian));
        System.out.println("Secans wynosi: " + radiany.Secans(radian));
        System.out.println("Cosecans wynosi: " + radiany.Cosecans(radian));
    }
}
