package zadanie5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    private PrintWriter zapis;
    String name;
    String surname;
    Scanner klawiatura = new Scanner(System.in);
    {
        try{
            zapis = new PrintWriter("dane.txt");
        }catch(FileNotFoundException extra){
            throw new RuntimeException(extra);
        }
    }
    public static void main(String[] args)throws FileNotFoundException
    {
        Main xd = new Main();
        xd.czytaj_dane();
        xd.zapisz_dane_do_pliku();
        xd.czytaj_dane_z_pliku();
    }
    public void czytaj_dane()
    {
        System.out.println("Napisz imie: ");
        name = klawiatura.nextLine();
        System.out.println("Napisz nazwisko: ");
        surname = klawiatura.nextLine();
    }
    public void zapisz_dane_do_pliku()
    {
        System.out.println("Dane z pliku: ");
        zapis.write(name + ", " + surname);
        zapis.close();
    }
    public void czytaj_dane_z_pliku()
    {
        try
        {
            Scanner skann = new Scanner(new File("dane.txt"));
            while (skann.hasNext())
            {
                System.out.println(skann.nextLine());
            }
            skann.close();
        }catch (FileNotFoundException extra) {
            throw new RuntimeException(extra);
        }
    }
}
