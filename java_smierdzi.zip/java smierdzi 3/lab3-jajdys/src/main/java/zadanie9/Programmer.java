package zadanie9;
public class Programmer extends Employee{
    protected String languages;
    public Programmer(String name, String surename, String languages)
    {
        super(name, surename);
        this.languages = languages;
    }
    public String getLanguages()
    {
        return languages;
    }
    public void setLanguages(String languages)
    {
        this.languages = languages;
    }
    @Override
    public String toString() {
        return name + "\n" + surename + "\n" + languages;
    }
}
