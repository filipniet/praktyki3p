package zadanie9;

public class Main {
    public static void main(String[] args) {
        Programmer smierdzi = new Programmer("Paweł", "Kozacki", "C#, Java, JavaScript");

        System.out.println(smierdzi.toString());
    }
}
