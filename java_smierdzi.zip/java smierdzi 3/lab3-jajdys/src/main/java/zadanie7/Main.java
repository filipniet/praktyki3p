package zadanie7;

public class Main {
    public static void main(String[] args) {
        Bike rower = new Bike("Marka Roweru 1", "Model nr 1");
        MotorBike motorower = new MotorBike("Marka Roweru 2", "Model nr 2");

        rower.printInfo();
        motorower.printInfo();
    }
}
