package zadanie14;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner skaner = new Scanner(System.in);
        System.out.print("Podaj liczbe: ");
        try
        {
            double input = skaner.nextInt();
            System.out.println();
            System.out.println("Twoja odwrocona liczba: 1/" + input + " = " + 1/input);
        } catch(Exception extra){
            extra.printStackTrace();
        }
    }
}
