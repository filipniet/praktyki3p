package zadanie12;

import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner skaner = new Scanner(System.in);

        System.out.print("Podaj miarę kąta: ");
        double miara = skaner.nextDouble();

        double radians = Angle.radian(miara);
        double degrees = Angle.degree(radians);
        Angle bok1 = new Angle(degrees);
        Angle bok2 = new Angle(radians);

        System.out.println("Radiany");
        System.out.println("Sinus wynosi: " + bok2.sinus(radians));
        System.out.println("Cosinus wynosi: " + bok2.cosinus(radians));
        System.out.println("Tanges wynosi: " + bok2.tanges(radians));
        System.out.println("Cotanges wynosi: " + bok2.cotanges(radians));
        System.out.println("Secans wynosi: " + bok2.secans(radians));
        System.out.println("Cosecans wynosi: " + bok2.cosecans(radians));
        System.out.println();
        System.out.println("Stopnie: ");
        System.out.println("Sinus wynosi: " + bok1.sinus(degrees));
        System.out.println("Cosinus wynosi: " + bok1.cosinus(degrees));
        System.out.println("Tanges wynosi: " + bok1.tanges(degrees));
        System.out.println("Cotanges wynosi: " + bok1.cotanges(degrees));
        System.out.println("Secans wynosi: " + bok1.secans(degrees));
        System.out.println("Cosecans wynosi: " + bok1.cosecans(degrees));
    }
}
