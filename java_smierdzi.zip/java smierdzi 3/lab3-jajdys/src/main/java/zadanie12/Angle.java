package zadanie12;

public class Angle {
    private double x;

    public Angle(double x) {
        this.x = x;
    }
    public double sinus(double x){
        return Math.sin(x);
    }
    public double cosinus(double x){
        return Math.cos(x);
    }
    public double tanges(double x){
        return Math.tan(x);
    }
    public double cotanges(double x){
        return 1.0/Math.tan(x);
    }
    public double secans(double x){
        return 1.0/Math.cos(x);
    }
    public double cosecans(double x){
        return 1.0/Math.sin(x);
    }
    public static double radian(double x){
        return Math.toRadians(x);
    }
    public static double degree(double x){
        return Math.toDegrees(x);
    }
}
