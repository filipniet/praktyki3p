package zadanie10;

public class TestException extends Exception{
    public TestException(){
        System.out.println("godzina nie moze byc ujemna");
    }
}
