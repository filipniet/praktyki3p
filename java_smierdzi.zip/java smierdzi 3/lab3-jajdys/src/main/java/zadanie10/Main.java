package zadanie10;

public class Main {
    public static void main(String[] args) {
        int id;

        try{
            id=69/0;
        } catch(ArithmeticException extraa){
            extraa.printStackTrace();
        } finally{
            System.out.println("wywolano wyjatek");
        }

        int a=-65;

        try{
            wywolanie(a);
        } catch (TestException extra) {
            extra.printStackTrace();
        }
    }
    private static void wywolanie(int godzina) throws TestException{
        if (godzina < 0){
            throw new TestException();
        }
    }
}
